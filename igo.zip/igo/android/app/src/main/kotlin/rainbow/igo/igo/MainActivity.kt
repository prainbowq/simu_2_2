package rainbow.igo.igo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
